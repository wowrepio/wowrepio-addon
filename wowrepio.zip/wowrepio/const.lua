local _, ns = ...

ns.tooltipLineLocked = false
ns.loaded = false
ns.FACTION_TO_ID = {Alliance = 1, Horde = 2, Neutral = 3}
ns.REGIONS = {"us", "kr", "eu", "tw", "cn"}