local _, ns = ...

local wowrepio = ns:AddModule("wowrepio")

function wowrepio:OnReady()
    print("Thank you for using " .. NORMAL_FONT_COLOR_CODE .. "wowrep.io! " .. RED_FONT_COLOR_CODE .. "<3")
end
