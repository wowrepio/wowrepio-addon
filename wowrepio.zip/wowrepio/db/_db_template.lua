local _, ns = ...

ns.DATABASE = {}

-- HERE ARE DRAGONS --